package com.example.tatkalfast

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import java.util.Calendar
import kotlinx.coroutines.delay

data class Passenger(val name:String,val age:String,val gender:String,val berth:String)
data class Preset(val name:String,val from:String,val to:String)

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){
  super.onCreate(savedInstanceState)
  setContent{ App() }
 }
}

@Composable
fun Countdown(targetHour:Int, targetMinute:Int):String{
 var now by remember{mutableStateOf(System.currentTimeMillis())}
 LaunchedEffect(Unit){ while(true){ now=System.currentTimeMillis(); delay(1000) } }
 val c=Calendar.getInstance()
 c.set(Calendar.HOUR_OF_DAY,targetHour); c.set(Calendar.MINUTE,targetMinute); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0)
 if(c.timeInMillis<=now)c.add(Calendar.DAY_OF_YEAR,1)
 var s=(c.timeInMillis-now)/1000
 val h=s/3600; s%=3600; val m=s/60; val sec=s%60
 return "%02d:%02d:%02d".format(h,m,sec)
}

@Composable
fun App(){
 var tab by remember{mutableIntStateOf(0)}
 var from by remember{mutableStateOf("")}
 var to by remember{mutableStateOf("")}
 var date by remember{mutableStateOf("")}
 var quota by remember{mutableStateOf("Tatkal")}
 var train by remember{mutableStateOf("")}
 var name by remember{mutableStateOf("")}
 var age by remember{mutableStateOf("")}
 var gender by remember{mutableStateOf("Male")}
 var berth by remember{mutableStateOf("No Preference")}
 var passengers by remember{mutableStateOf(listOf<Passenger>())}
 var presets by remember{mutableStateOf(listOf(
  Preset("Home → Delhi","NDLS","GZB"),
  Preset("Delhi → Home","GZB","NDLS")
 ))}
 val countdown=Countdown(10,0)

 MaterialTheme{
  Scaffold(
   topBar={TopAppBar(title={Text("Tatkal Fast Pro",fontWeight=FontWeight.Bold)})},
   bottomBar={
    NavigationBar{
     NavigationBarItem(tab==0,{tab=0},{Text("Book")},icon={Text("🚆")})
     NavigationBarItem(tab==1,{tab=1},{Text("Passengers")},icon={Text("👤")})
     NavigationBarItem(tab==2,{tab=2},{Text("Presets")},icon={Text("⚡")})
    }
   }
  ){ pad->
   LazyColumn(Modifier.padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
    if(tab==0){
     item{
      Card(Modifier.fillMaxWidth()){
       Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
        Text("Tatkal preparation",style=MaterialTheme.typography.titleMedium)
        Text("Next configurable opening countdown")
        Text(countdown,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Text("Opening time can be changed in the app settings when required.",style=MaterialTheme.typography.bodySmall)
       }
      }
     }
     item{ OutlinedTextField(from,{from=it},Modifier.fillMaxWidth(),label={Text("From station")},singleLine=true) }
     item{ OutlinedTextField(to,{to=it},Modifier.fillMaxWidth(),label={Text("To station")},singleLine=true) }
     item{ OutlinedTextField(date,{date=it},Modifier.fillMaxWidth(),label={Text("Journey date (DD/MM/YYYY)")},singleLine=true) }
     item{ OutlinedTextField(train,{train=it},Modifier.fillMaxWidth(),label={Text("Train number/name (optional)")},singleLine=true) }
     item{
      Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
       FilterChip(quota=="Tatkal",{quota="Tatkal"},{Text("Tatkal")})
       FilterChip(quota=="Premium Tatkal",{quota="Premium Tatkal"},{Text("Premium Tatkal")})
      }
     }
     item{
      Card(Modifier.fillMaxWidth()){
       Column(Modifier.padding(12.dp)){
        Text("Selected passengers: ${passengers.size}",fontWeight=FontWeight.Bold)
        passengers.forEach{p->Text("${p.name} • ${p.age} • ${p.gender} • ${p.berth}")}
       }
      }
     }
     item{
      Button(
       onClick={
        val i=Intent(Intent.ACTION_VIEW,Uri.parse("https://www.irctc.co.in/"))
        // Official IRCTC flow only; no security/CAPTCHA/OTP bypass.
        try { startActivity(i) } catch(_:Exception) { }
       },
       Modifier.fillMaxWidth()
      ){Text("Open Official IRCTC")}
     }
    } else if(tab==1){
     item{Text("Passenger profiles",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}
     item{OutlinedTextField(name,{name=it},Modifier.fillMaxWidth(),label={Text("Full name")},singleLine=true)}
     item{OutlinedTextField(age,{age=it},Modifier.fillMaxWidth(),label={Text("Age")},singleLine=true)}
     item{
      Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
       listOf("Male","Female","Other").forEach{g->FilterChip(gender==g,{gender=g},{Text(g)})}
      }
     }
     item{
      Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
       Text("Berth:")
       listOf("No Preference","Lower","Middle","Upper","Side Lower","Side Upper").forEach{b->
        if(b in listOf("No Preference","Lower","Middle","Upper","Side Lower","Side Upper"))
         FilterChip(berth==b,{berth=b},{Text(b)})
       }
      }
     }
     item{
      Button(onClick={
       if(name.isNotBlank() && age.toIntOrNull()!=null){
        passengers=passengers+Passenger(name.trim(),age.trim(),gender,berth)
        name="";age=""
       }
      },Modifier.fillMaxWidth()){Text("Save passenger")}
     }
     items(passengers){p->
      Card(Modifier.fillMaxWidth()){
       Row(Modifier.padding(12.dp),Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
        Column{Text(p.name,fontWeight=FontWeight.Bold);Text("${p.age} • ${p.gender} • ${p.berth}")}
        TextButton(onClick={passengers=passengers.filterNot{it==p}}){Text("Delete")}
       }
      }
     }
    } else {
     item{Text("Quick journey presets",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}
     item{Text("One tap se From/To fill karein.")}
     items(presets){p->
      Card(Modifier.fillMaxWidth()){
       Row(Modifier.padding(12.dp),Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
        Column{Text(p.name,fontWeight=FontWeight.Bold);Text("${p.from} → ${p.to}")}
        Button(onClick={from=p.from;to=p.to}){Text("Use")}
       }
      }
     }
     item{
      Button(onClick={presets=presets+Preset("New route","FROM","TO")},Modifier.fillMaxWidth()){Text("Add preset")}
     }
     item{
      HorizontalDivider()
      Spacer(Modifier.height(8.dp))
      Text("Speed design",fontWeight=FontWeight.Bold)
      Text("Local-first UI • minimal screens • no unnecessary background work • official IRCTC handoff")
     }
    }
   }
  }
 }
}
