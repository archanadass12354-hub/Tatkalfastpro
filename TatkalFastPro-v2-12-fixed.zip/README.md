# Tatkal Fast Pro — Android v2

A fast, lightweight personal-use preparation app for railway booking.

## Included
- Clean 3-tab UI: Book / Passengers / Presets
- Passenger profiles with age, gender and berth preference
- Quick journey presets
- Configurable-ready Tatkal countdown UI
- Train number/name field
- Tatkal / Premium Tatkal selection
- Input validation
- Local-first UI architecture
- Official IRCTC handoff
- No CAPTCHA/OTP/security bypass
- No automated payment or ticket submission

## Important
This project is intentionally designed as a booking-preparation/assistant app. Any production integration must use an IRCTC-authorized API or official booking flow and comply with current IRCTC terms and security requirements.

## Production improvements
- Encrypted persistent passenger storage (Android Keystore)
- Offline station database + instant autocomplete
- Configurable quota opening time
- Android notification/alarm for countdown
- Network status and graceful retry
- Accessibility and dark mode
- Official API integration only if authorized

## v2.0.1 fix
- Fixed Official IRCTC button to launch the official website.
- Fixed Middle berth option visibility.
